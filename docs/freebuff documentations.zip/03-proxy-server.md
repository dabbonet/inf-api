# Python TLS Proxy Server

## Overview

A Python HTTP proxy server that forwards requests to `https://www.codebuff.com` using `tls_client` with a Chrome 124 TLS profile. This bypasses JA3 TLS fingerprinting that blocks standard HTTP clients.

## How It Works

```
Client (fetch/curl) ──HTTP──▶ Proxy (:8323) ──TLS(Chrome124)──▶ www.codebuff.com
```

- Client connects to proxy via plain HTTP (no TLS needed)
- Proxy connects to codebuff.com using `tls_client` with Chrome 124 profile
- Server sees Chrome-like JA3 fingerprint → allows request
- Proxy forwards response back to client

## Prerequisites

```bash
pip3 install --break-system-packages tls-client typing_extensions
```

## Server Code

**Location in container**: `/home/node/.openclaw/extensions/codebuff/proxy.py`
**Location in repo**: See `proxy.py` in the root of this documentation

```python
#!/usr/bin/env python3
"""
Codebuff TLS Proxy — bypasses JA3 TLS fingerprinting.

Listens on localhost:8323 and forwards all requests to https://www.codebuff.com
using tls_client with a Chrome 124 profile to produce a browser-like JA3 fingerprint.
"""

import json
import logging
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

import tls_client

# ── Configuration ────────────────────────────────────────────────────────────
PROXY_HOST = "127.0.0.1"
PROXY_PORT = 8323
UPSTREAM_BASE = "https://www.codebuff.com"

# Headers that MUST be forwarded (needed for auth/content-type)
FORWARD_HEADERS = {
    "authorization",
    "content-type",
    "origin",
    "referer",
}

# Headers that MUST be removed (cause Cloudflare blocks)
REMOVE_HEADERS = {
    "user-agent",
    "accept-encoding",
    "connection",
    "host",
    "keep-alive",
    "proxy-connection",
    "transfer-encoding",
}

# ── TLS Session Pool ─────────────────────────────────────────────────────────
_sessions = {}

def get_tls_session():
    """Get or create a tls_client session with Chrome 124 profile."""
    if "default" not in _sessions:
        _sessions["default"] = tls_client.Session(
            client_identifier="chrome_124",
            random_tls_extension_order=True,
        )
    return _sessions["default"]

# ── HTTP Handler ──────────────────────────────────────────────────────────────
class ProxyHandler(BaseHTTPRequestHandler):
    def do_request(self):
        """Forward any HTTP method to upstream."""
        session = get_tls_session()

        # Build upstream URL
        parsed = urlparse(self.path)
        upstream_url = UPSTREAM_BASE + self.path

        # Read request body
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else None

        # Build upstream headers (only essential ones)
        upstream_headers = {}
        for key, value in self.headers.items():
            lower_key = key.lower()
            if lower_key in FORWARD_HEADERS:
                upstream_headers[key] = value
            elif lower_key == "x-freebuff-session":
                upstream_headers["x-freebuff-session"] = value

        # Ensure content-type is set
        if "Content-Type" not in upstream_headers:
            upstream_headers["Content-Type"] = "application/json"

        # Map method
        method = self.command.upper()

        # Make upstream request
        try:
            response = session.request(
                method=method,
                url=upstream_url,
                headers=upstream_headers,
                body=body,
                allow_redirects=False,  # Don't follow redirects (keep headers intact)
            )

            # Send response
            self.send_response(response.status_code)

            # Forward response headers (filtered)
            for key, value in response.headers.items():
                lower_key = key.lower()
                if lower_key not in {"transfer-encoding", "connection", "content-encoding", "content-length"}:
                    self.send_header(key, value)

            # Send body
            resp_body = response.content
            self.send_header("Content-Length", str(len(resp_body)))
            self.end_headers()
            self.wfile.write(resp_body)

        except Exception as e:
            error_msg = f"Proxy error: {str(e)}".encode()
            self.send_response(502)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(error_msg)))
            self.end_headers()
            self.wfile.write(error_msg)

    def do_GET(self):    return self.do_request()
    def do_POST(self):   return self.do_request()
    def do_PUT(self):    return self.do_request()
    def do_DELETE(self): return self.do_request()
    def do_PATCH(self):  return self.do_request()

    def log_message(self, format, *args):
        """Log requests to stderr."""
        logging.info(f"[proxy] {self.address_string()} {format % args}")

# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stderr)],
    )

    # Pre-warm TLS session
    get_tls_session()

    server = HTTPServer((PROXY_HOST, PROXY_PORT), ProxyHandler)
    logging.info(f"Codebuff TLS proxy listening on http://{PROXY_HOST}:{PROXY_PORT}")
    logging.info(f"Forwarding to {UPSTREAM_BASE}")
    logging.info("TLS client: chrome_124 profile")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logging.info("Shutting down proxy...")
        server.shutdown()

if __name__ == "__main__":
    main()
```

## Setup Instructions

### 1. Install Dependencies (in container)

```bash
docker exec -u root dabbo pip3 install --break-system-packages tls-client typing_extensions
```

### 2. Start Proxy Manually

```bash
docker exec -u root dabbo bash -c 'nohup python3 /home/node/.openclaw/extensions/codebuff/proxy.py > /tmp/proxy.log 2>&1 &'
```

### 3. Verify Proxy Is Running

```bash
curl -s http://localhost:8323/health
# Should return: OK
```

### 4. Test Through Proxy

```bash
curl -s http://localhost:8323/api/v1/freebuff/session \
  -H "Authorization: Bearer cb-pat-ff60c395ec09d3fcb405a84b667254552594f134517e4ce4fe923c3fbd58e206" \
  -H "Content-Type: application/json" \
  -d '{"model": "minimax/minimax-m3"}'
```

## Auto-Start on Container Boot

The container entrypoint (`/tmp/dabbo-entrypoint.sh` on host) should:
1. Install pip dependencies
2. Start the proxy
3. Then start the gateway

```bash
#!/bin/bash
# Install Python deps for TLS proxy
pip3 install --break-system-packages tls-client typing_extensions 2>/dev/null

# Start TLS proxy in background
nohup python3 /home/node/.openclaw/extensions/codebuff/proxy.py > /tmp/proxy.log 2>&1 &
PROXY_PID=$!
echo "TLS proxy started (PID: $PROXY_PID)"

# Wait for proxy to be ready
for i in $(seq 1 10); do
    if curl -s http://127.0.0.1:8323/health > /dev/null 2>&1; then
        echo "Proxy ready"
        break
    fi
    sleep 0.5
done

# Start OpenClaw gateway as node user
exec runuser -u node -- node /app/openclaw.mjs gateway --bind custom --port 33815 -- "$@"
```

## Important Pitfalls

### NEVER Forward User-Agent Header

The proxy must **never** forward the `User-Agent` header from the client to the upstream server. Cloudflare (in front of codebuff.com) blocks non-browser User-Agents with a 400 error.

**Correct** (proxy strips User-Agent):
```
Client: User-Agent: curl/7.88.1
Proxy strips it → upstream sees no User-Agent → 200 OK
```

**Wrong** (proxy forwards User-Agent):
```
Client: User-Agent: curl/7.88.1
Proxy forwards it → upstream sees curl → Cloudflare 400 Bad Request
```

### Redirect Handling

The proxy should NOT follow redirects (`allow_redirects=False`) because redirects to `codebuff.com` strip the `Authorization` header.

### Session Persistence

The `tls_client.Session` object maintains TLS state across requests. Create ONE session and reuse it for all requests. Creating a new session for each request would generate a new TLS fingerprint each time.

## Proxy Logs

Logs go to `/tmp/proxy.log`:
```
2026-06-09 21:15:30,123 [INFO] [proxy] 127.0.0.1 GET /health
2026-06-09 21:15:31,456 [INFO] [proxy] 127.0.0.1 POST /api/v1/freebuff/session
2026-06-09 21:15:32,789 [INFO] [proxy] 127.0.0.1 POST /api/v1/agent-runs
2026-06-09 21:15:33,012 [INFO] [proxy] 127.0.0.1 POST /api/v1/chat/completions
```

## Testing the Full Flow Through Proxy

```bash
# Step 1: Create session
SESSION=$(curl -s http://localhost:8323/api/v1/freebuff/session \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "minimax/minimax-m3"}')
echo $SESSION | jq .
SESSION_ID=$(echo $SESSION | jq -r '.id')

# Step 2: Create agent run
RUN=$(curl -s http://localhost:8323/api/v1/agent-runs \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"action\": \"START\", \"agentId\": \"base2-free-minimax-m3\"}")
echo $RUN | jq .
RUN_ID=$(echo $RUN | jq -r '.id')

# Step 3: Chat completion
curl -s http://localhost:8323/api/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"model\": \"minimax/minimax-m3\",
    \"stream\": true,
    \"messages\": [{\"role\": \"user\", \"content\": \"Hello!\"}],
    \"codebuff_metadata\": {
      \"session_id\": \"$SESSION_ID\",
      \"run_id\": \"$RUN_ID\"
    }
  }"
```
