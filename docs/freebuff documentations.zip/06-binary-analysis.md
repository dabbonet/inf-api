# Binary Analysis — Freebuff CLI

## Binary Details

- **Path**: `/root/.config/manicode/freebuff`
- **Size**: 129MB (Bun-compiled)
- **Version**: 0.0.104 (from `--version`)
- **Runtime**: Bun (self-contained binary)
- **Original location**: `/root/.cache/manicode/freebuff`

## Installation Method

The freebuff binary was installed via npm:
```bash
npm install -g freebuff
# Downloads from: https://registry.npmjs.org/freebuff/-/freebuff-0.0.104.tgz
# Installs binary at: /root/.config/manicode/freebuff
```

## Runtime Analysis

### Process Execution
```bash
# Binary path: /root/.config/manicode/freebuff
# Main thread: node:26299
# Thread pool (Bun): 26314, 26315, 26316, 26317, 26318, 26319, 26320
```

### Memory Maps
- Bun's JavaScriptCore VM at `0xa74600000`
- No embedded secrets visible in `/proc/PID/maps`
- Bun uses lazy loading — secrets aren't in memory until accessed

### Network Behavior
- Uses HTTP/1.1 (not HTTP/2)
- epoll for async I/O (not standard read/write)
- Can't be intercepted with strace's read/write tracing

## API Endpoints Used by Binary

All endpoints use `codebuff.com` (NOT `freebuff.com`):

```
GET  /api/v1/cli-config
GET  /api/v1/free-models
GET  /health
GET  /login/free
POST /api/v1/freebuff/session
DELETE /api/v1/freebuff/session
POST /api/v1/agent-runs
POST /api/v1/chat/completions
GET  /api/v1/me
```

## CLI Arguments

```bash
freebuff --help
# Shows: codebuff v0.0.104

freebuff --version
# Shows: 0.0.104

freebuff --debug
# Enables debug logging

freebuff --model <model>
# Specifies model (e.g., minimax/minimax-m3)

freebuff --agent <agent>
# Specifies agent (e.g., base2-free-minimax-m3)
```

## Authentication Flow

1. Binary reads API key from `~/.codebuff/auth.json`
2. Sends `Authorization: Bearer <key>` with all requests
3. No cookies used
4. No OAuth flow for free mode

## Waiting Room Behavior

1. Binary checks queue position periodically
2. Uses exponential backoff (starts slow, speeds up)
3. When position reaches 0, proceeds to agent run
4. Shows progress bar during wait

## JA3 Fingerprint

The binary's TLS Client Hello produces JA3:
```
a3afc2c46ba4a7d7fbe1cfb7a3031c2f
```

This is the SAME fingerprint produced by `tls_client` with Chrome 124 profile. This is why `tls_client` bypasses the server's check.

## Dead End: Decompilation

The binary is 129MB of Bun-compiled JavaScript. Attempts to decompile:
- **Bun decompiler**: Not available
- **strings analysis**: No useful API keys or secrets found
- **Ghidra/IDA**: Not installed, binary too large
- **JSDetox**: Not compatible with Bun format

The binary analysis was useful for understanding the API flow but the actual bypass came from TLS fingerprinting, not from reverse-engineering the binary code.

## Key Learnings

1. The binary uses `codebuff.com` API, NOT `freebuff.com`
2. Free mode uses the same API endpoints as paid mode
3. The `free_mode_cli_required` error is triggered by TLS fingerprint, not by code analysis
4. The binary's JA3 matches Chrome 124's JA3 when using `tls_client`
5. The binary uses HTTP/1.1, not HTTP/2
