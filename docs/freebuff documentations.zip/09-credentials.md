# Credentials, Models, and Configuration

## API Keys

### Codebuff API Key
```
cb-pat-ff60c395ec09d3fcb405a84b667254552594f134517e4ce4fe923c3fbd58e206
```
- Used for: All Codebuff/Freebuff API calls
- Format: `cb-pat-<hex>`
- Location in container: `/home/node/.codebuff/auth.json`

### Auth Profiles
```json
{
  "codebuff:default": {
    "apiKey": "cb-pat-ff60c395ec09d3fcb405a84b667254552594f134517e4ce4fe923c3fbd58e206"
  }
}
```
Location: `/home/node/.openclaw/agents/main/agent/auth-profiles.json`

## Free Mode Models

| Model ID | Display Name | Agent ID | Context Length | Max Output |
|----------|--------------|----------|----------------|------------|
| `minimax/minimax-m3` | Minimax M3 | `base2-free-minimax-m3` | 1,000,000 | 16,384 |
| `mimo/mimo-v2.5-pro` | Mimo V2.5 Pro | `base2-free-mimo-pro` | 1,000,000 | 16,384 |
| `mimo/mimo-v2.5` | Mimo V2.5 | `base2-free-mimo` | 1,00,000 | 16,384 |
| `deepseek/deepseek-v4-pro` | Deepseek V4 Pro | `base2-free-deepseek-pro` | 1,000,000 | 16,384 |
| `deepseek/deepseek-v4-flash` | Deepseek V4 Flash | `base2-free-deepseek-flash` | 1,000,000 | 16,384 |
| `moonshotai/kimi-k2.6` | Kimi K2.6 | `base2-free-kimi` | 1,000,000 | 16,384 |

## Rate Limits

- **Free mode**: Limited requests per day
- **Reset time**: Midnight Pacific (`07:00:00.000Z` UTC)
- **Last known usage**: `recentCount: 4.3/5`
- **Session timeout**: Unknown, but sessions expire after some time

## Container Configuration

### Docker Container
- **Name**: `dabbo`
- **Image**: `ghcr.io/openclaw/openclaw:2026.6.1`
- **Entrypoint**: `runuser -u node -- node /app/openclaw.mjs gateway --bind custom --port 33815 --`
- **Custom entrypoint**: `/tmp/dabbo-entrypoint.sh` (starts proxy first)

### OpenClaw Config
- **Path**: `/home/ubuntu/dabbo-state/.openclaw/openclaw.json`
- **Port**: 33815
- **Bind**: custom (0.0.0.0)

### SSH Access
- **Host**: `34.6.156.250`
- **User**: `ubuntu`
- **Key**: `~/.ssh/google_compute_engine`

## Discord Configuration

- **Guild ID**: `1488383499500126362`
- **Bot ID**: `1488386316772179978`
- **Hamada Channel**: `1508218581350092992`

## GitHub Repository

- **URL**: `https://github.com/dabbonet/openclaw-codebuff-provider`
- **Visibility**: Private
- **Contains**: Refactored plugin code (6 files, 649 lines)

## TLS Fingerprinting

### Known JA3 Fingerprints
| Client | JA3 | Result |
|--------|-----|--------|
| curl (OpenSSL) | `0149f47e7c27b231ddac3990c3e94e34` | 403 Blocked |
| Bun (BoringSSL) | `d871d02c28b179dc85da1c7a40ce3b06` | 403 Blocked |
| Node.js (OpenSSL) | Same as curl | 403 Blocked |
| Python requests | Same as curl | 403 Blocked |
| Freebuff binary | `a3afc2c46ba4a7d7fbe1cfb7a3031c2f` | 200 OK |
| Chrome 124 (tls_client) | `a3afc2c46ba4a7d7fbe1cfb7a3031c2f` | 200 OK |

### Server Domain
- **API Domain**: `www.codebuff.com` (NOT `codebuff.com`)
- **Freebuff Domain**: `freebuff.com` (NO API endpoints)
- **Cloudflare**: Yes, blocks non-browser User-Agents

## Key Files

| File | Location | Purpose |
|------|----------|---------|
| `openclaw.json` | `/home/ubuntu/dabbo-state/.openclaw/` | Main config |
| `auth.json` | `/home/node/.codebuff/` | API key storage |
| `auth-profiles.json` | `/home/node/.openclaw/agents/main/agent/` | Provider auth |
| `proxy.py` | `/home/node/.openclaw/extensions/codebuff/` | TLS proxy |
| `dabbo-entrypoint.sh` | `/tmp/` on host | Container startup |
| `codebuff.ts` | `~/.config/opencode/plugins/` | OpenCode plugin |
| `server.js` | `~/.config/opencode/codebuff-proxy/` | OpenCode proxy |
