# OpenClaw TypeScript Plugin

## Overview

A TypeScript plugin for OpenClaw that provides Codebuff/Freebuff as a model provider. All requests are routed through the Python TLS proxy (port 8323) to bypass JA3 fingerprinting.

## Status

**NOT WORKING** — The plugin is never discovered by OpenClaw's plugin discovery system. The code is correct but the gateway silently skips it during startup.

## Plugin Files

### Directory Structure

```
/home/node/.openclaw/extensions/codebuff/
├── index.ts              # Main plugin entry point
├── openclaw.plugin.json  # Plugin manifest
├── package.json          # npm package config
├── proxy.py              # Python TLS proxy server
└── node_modules/         # (empty, no npm deps)
```

### package.json

```json
{
  "name": "codebuff",
  "version": "1.0.0",
  "type": "module",
  "openclaw": {
    "extensions": ["./index.ts"]
  }
}
```

### openclaw.plugin.json

```json
{
  "id": "codebuff",
  "version": "1.0.0",
  "displayName": "Codebuff",
  "description": "Codebuff/Freebuff free tier models via TLS proxy",
  "providerAuthChoices": [
    {
      "id": "codebuff",
      "label": "Codebuff API Key",
      "description": "Free Codebuff API key",
      "envVar": "CODEBUFF_API_KEY",
      "cliFlag": "--codebuff-api-key"
    }
  ]
}
```

### index.ts

```typescript
// Codebuff provider plugin for OpenClaw
// Routes all requests through local TLS proxy to bypass JA3 fingerprinting

const API_BASE = "http://127.0.0.1:8323/api/v1";

const FREEBUFF_MODELS: Record<string, { name: string; contextLength: number; maxOutput: number; agentId: string }> = {
  "minimax/minimax-m3": { name: "Minimax M3", contextLength: 1000000, maxOutput: 16384, agentId: "base2-free-minimax-m3" },
  "mimo/mimo-v2.5-pro": { name: "Mimo V2.5 Pro", contextLength: 1000000, maxOutput: 16384, agentId: "base2-free-mimo-pro" },
  "mimo/mimo-v2.5": { name: "Mimo V2.5", contextLength: 1000000, maxOutput: 16384, agentId: "base2-free-mimo" },
  "deepseek/deepseek-v4-pro": { name: "Deepseek V4 Pro", contextLength: 1000000, maxOutput: 16384, agentId: "base2-free-deepseek-pro" },
  "deepseek/deepseek-v4-flash": { name: "Deepseek V4 Flash", contextLength: 1000000, maxOutput: 16384, agentId: "base2-free-deepseek-flash" },
  "moonshotai/kimi-k2.6": { name: "Kimi K2.6", contextLength: 1000000, maxOutput: 16384, agentId: "base2-free-kimi" },
};

async function createSession(apiKey: string, model: string): Promise<{ id: string }> {
  // DELETE existing session first (sessions are model-bound)
  await fetch(`${API_BASE}/freebuff/session`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${apiKey}` },
  });

  const res = await fetch(`${API_BASE}/freebuff/session`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ model }),
  });

  if (!res.ok) throw new Error(`Session create failed: ${res.status}`);
  return await res.json();
}

async function createAgentRun(apiKey: string, agentId: string): Promise<{ id: string }> {
  const res = await fetch(`${API_BASE}/agent-runs`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ action: "START", agentId }),
  });

  if (!res.ok) throw new Error(`Agent run failed: ${res.status}`);
  return await res.json();
}

export default function codebuffPlugin(options?: { apiKey?: string }) {
  const apiKey = options?.apiKey;

  return {
    name: "codebuff",
    providers: [
      {
        id: "codebuff",
        name: "Codebuff Free",
        getModels() {
          return Object.entries(FREEBUFF_MODELS).map(([id, info]) => ({
            id,
            name: info.name,
            contextLength: info.contextLength,
            maxOutput: info.maxOutput,
          }));
        },
        async *doStream({ prompt, model, system }: { prompt: string; model: string; system?: string }) {
          if (!apiKey) throw new Error("Codebuff API key required");

          const modelInfo = FREEBUFF_MODELS[model];
          if (!modelInfo) throw new Error(`Unknown model: ${model}`);

          // Step 1: Create session
          const session = await createSession(apiKey, model);

          // Step 2: Create agent run
          const run = await createAgentRun(apiKey, modelInfo.agentId);

          // Step 3: Stream chat completion
          const messages = [];
          if (system) messages.push({ role: "system", content: system });
          messages.push({ role: "user", content: prompt });

          const res = await fetch(`${API_BASE}/chat/completions`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model,
              stream: true,
              messages,
              codebuff_metadata: {
                session_id: session.id,
                run_id: run.id,
              },
            }),
          });

          if (!res.ok) {
            const err = await res.text();
            throw new Error(`Chat completions failed (${res.status}): ${err}`);
          }

          // Parse SSE stream
          const reader = res.body?.getReader();
          if (!reader) throw new Error("No response body");

          const decoder = new TextDecoder();
          let buffer = "";

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            for (const line of lines) {
              if (!line.startsWith("data: ")) continue;
              const data = line.slice(6).trim();
              if (data === "[DONE]") return;

              try {
                const chunk = JSON.parse(data);
                const delta = chunk.choices?.[0]?.delta;
                if (delta?.reasoning_content) {
                  yield { type: "reasoning", text: delta.reasoning_content };
                }
                if (delta?.content) {
                  yield { type: "text", text: delta.content };
                }
              } catch {}
            }
          }
        },
      },
    ],
  };
}
```

## Why It Doesn't Load

The OpenClaw plugin discovery system silently skips the codebuff plugin. We've verified:

- ✅ File permissions: All files owned by `node:node`, `0644`
- ✅ File structure: Identical to working `commandcode` plugin
- ✅ `package.json`: Has `openclaw.extensions: ["./index.ts"]`
- ✅ `openclaw.plugin.json`: Has `id: "codebuff"`
- ✅ `plugins.entries.codebuff.enabled: true` in config
- ✅ No `fs`/`path` Node.js builtin imports
- ✅ Container restart doesn't help

**What was tried**:
1. Removing `fs`/`path` imports → still not discovered
2. Adding to `plugins.allow: ["codebuff"]` → gateway says "plugins.allow is empty"
3. Removing `plugins.allow` entirely → still not discovered
4. Copying commandcode structure exactly → still not discovered
5. Checking file ownership/permissions → correct
6. Checking config file path → only one openclaw.json
7. Restarting container multiple times → same result

**Possible causes**:
1. The discovery system may use a cached file list that doesn't include new files
2. The discovery system may require a specific npm install method
3. There may be a bug in the discovery system for extensions directory
4. The discovery may check a different attribute that's missing

## Workaround

Use the Python TLS proxy directly via HTTP. The proxy is already working and can be called from any HTTP client. The OpenClaw plugin is optional — the proxy is the critical component.

## Configuration

In `openclaw.json`:
```json
{
  "plugins": {
    "entries": {
      "codebuff": {
        "enabled": true,
        "config": {
          "apiKey": "cb-pat-ff60c395ec09d3fcb405a84b667254552594f134517e4ce4fe923c3fbd58e206"
        }
      }
    }
  },
  "agents": {
    "providers": {
      "codebuff": {
        "enabled": true
      }
    }
  }
}
```
