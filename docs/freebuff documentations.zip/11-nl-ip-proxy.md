# NL IP Proxy — Current Working Setup

## Overview

A Node.js HTTP proxy that provides free access to Codebuff's AI models by routing through a Netherlands (NL) IP address. Codebuff's free tier is gated by **IP geolocation**, not TLS fingerprinting — requests from NL IPs bypass all checks and get full free tier access.

## Architecture

```
┌──────────┐     ┌──────────────────────────┐     ┌─────────────────────┐
│ OpenCode │────▶│  Node.js Proxy (:3456)  │────▶│  codebuff.com API   │
│ (local)  │     │  (GCP VPS, Netherlands) │     │  (free tier)        │
└──────────┘     └──────────────────────────┘     └─────────────────────┘
                                            │
                                    Netherlands IP
                                    (bypasses all TLS checks)
```

### Components

1. **VPS Proxy** (GCP `europe-west4`, Netherlands)
   - Node.js HTTP server on port 3456
   - Receives OpenAI-compatible requests
   - Manages Codebuff freebuff sessions + agent runs
   - Forwards chat completions to Codebuff API

2. **OpenCode** (local machine)
   - Configured with `codebuff` provider pointing to `http://34.6.156.250:3456/v1`

## How the Proxy Works

### Flow (per request)

```
Client (OpenCode)                  Proxy (:3456)                   codebuff.com API
      │                                │                                │
      │── POST /v1/chat/completions ──▶│                                │
      │   {model, messages, tools,     │                                │
      │    temperature, max_tokens,    │                                │
      │    stream: true}               │                                │
      │                                │── DELETE /freebuff/session ──▶│
      │                                │◀─ 200 (old session ended) ───│
      │                                │── POST /freebuff/session ────▶│
      │                                │◀─ {instanceId, ...} ──────────│
      │                                │── POST /agent-runs ──────────▶│
      │                                │◀─ {runId, ...} ──────────────│
      │                                │── POST /chat/completions ────▶│
      │                                │   {original body +            │
      │                                │    codebuff_metadata: {       │
      │                                │      run_id,                  │
      │                                │      freebuff_instance_id     │
      │                                │    }}                         │
      │◀─ SSE stream (raw pipe) ──────│◀─ SSE stream ─────────────────│
      │   (reasoning_content,          │                               │
      │    tool_calls, content,        │                               │
      │    finish_reason, usage)       │                               │
```

### Key Design Decisions

#### 1. Forward Original Body As-Is

**Decision**: The proxy does NOT reconstruct the request body. It forwards the original body from OpenCode/curl, only injecting `codebuff_metadata` and forcing `stream: true`.

**Why**: Reconstructing the body would drop:
- `tools` and `tool_choice` — tool definitions
- `temperature`, `top_p`, `max_tokens` — generation parameters
- `stop` — stop sequences
- `presence_penalty`, `frequency_penalty` — repetition controls
- Any other OpenAI-compatible parameter

The original Python TLS proxy (`proxy.py`) also forwarded the body unchanged — it was a generic forward proxy.

#### 2. Raw SSE Pipe

**Decision**: The SSE stream is piped directly from Codebuff to the client without any filtering or transformation.

**Why**: 
- OpenCode natively handles `reasoning_content` (thinking/reasoning tokens shown as "+ Thought: X.Xs")
- OpenCode natively handles `tool_calls` deltas (streaming function arguments)
- OpenCode natively handles `finish_reason` and `usage`
- Any filtering (e.g., stripping `reasoning_content`) caused empty content chunks and garbled tool calls

#### 3. Session per Request (No Caching)

**Decision**: Every request chain creates a fresh session (DELETE + POST) and run.

**Why**:
- Avoid stale session state bugs (the previous caching approach stored `instanceId: undefined` after a race condition, breaking all subsequent requests)
- Sessions are model-bound — caching makes model switching fragile
- The cost (one extra HTTP round trip per request) is negligible

#### 4. Sequential DELETE + POST

**Decision**: The DELETE (clear old session) is awaited before the POST (create new session).

**Why**: Sessions are model-bound. If you create a session for `deepseek/deepseek-v4-flash` and then try to create one for `moonshotai/kimi-k2.6` without deleting the first, Codebuff returns `{"status":"model_locked","currentModel":"deepseek/deepseek-v4-flash"}`. The DELETE must complete before the POST to release the model lock.

## Codebuff 3-Step Free Flow

### Step 1: Create Session

```
DELETE /api/v1/freebuff/session
Headers: Authorization, x-freebuff-model: <model>
→ 200 {"status": "ended"}

POST /api/v1/freebuff/session
Headers: Authorization, x-freebuff-model: <model>
Body: {}
→ 200 {"instanceId": "<uuid>", "status": "active", "accessTier": "full", ...}
```

### Step 2: Create Agent Run

```
POST /api/v1/agent-runs
Headers: Authorization
Body: {"action": "START", "agentId": "<agent_id>", "instanceId": "<instanceId>"}
→ 200 {"runId": "<uuid>"}
```

**Agent IDs** (must match the model):

| Model | Agent ID |
|-------|----------|
| `deepseek/deepseek-v4-flash` | `base2-free-deepseek-flash` |
| `deepseek/deepseek-v4-pro` | `base2-free-deepseek-pro` |
| `mimo/mimo-v2.5` | `base2-free-mimo` |
| `mimo/mimo-v2.5-pro` | `base2-free-mimo-pro` |
| `moonshotai/kimi-k2.6` | `base2-free-kimi` |
| `minimax/minimax-m3` | `base2-free-minimax-m3` |

### Step 3: Chat Completion

```
POST /api/v1/chat/completions
Headers: Authorization, Content-Type
Body: {
  "model": "<model>",
  "messages": [...],
  "stream": true,
  "tools": [...],           // ← forwarded as-is from client
  "temperature": 0.7,       // ← forwarded as-is from client
  "codebuff_metadata": {
    "run_id": "<runId>",
    "freebuff_instance_id": "<instanceId>"
  }
}
→ SSE stream
```

## VPS Setup

### GCP VM Configuration

- **Region**: `europe-west4` (Netherlands)
- **Machine type**: `e2-micro` (free tier eligible, 2 vCPU, 1 GB RAM — more than enough)
- **Firewall**: Allow TCP:3456 from your IP only
- **Image**: Ubuntu 22.04 LTS

### Proxy Deployment

```bash
# Copy proxy to VPS
scp -i ~/.ssh/google_compute_engine codebuff-proxy.js ubuntu@<VPS_IP>:/tmp/

# Create systemd service
ssh -i ~/.ssh/google_compute_engine ubuntu@<VPS_IP>

# /etc/systemd/system/codebuff-proxy.service:
[Unit]
Description=Codebuff Proxy (NL IP)
After=network.target

[Service]
ExecStart=/usr/bin/node /tmp/codebuff-proxy.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable codebuff-proxy.service
sudo systemctl start codebuff-proxy.service
```

### Health Check

```bash
curl -s http://34.6.156.250:3456/v1/models
# → {"object":"list","data":[{...},...]}

curl -s http://34.6.156.250:3456/v1/chat/completions \
  -X POST -H "Content-Type: application/json" \
  -H "Authorization: Bearer codebuff-free" \
  -d '{"model":"deepseek/deepseek-v4-flash","messages":[{"role":"user","content":"hi"}],"stream":true}'
# → SSE stream with cost: 0
```

## OpenCode Configuration

```json
{
  "provider": {
    "codebuff": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Codebuff (Free via NL)",
      "options": {
        "baseURL": "http://34.6.156.250:3456/v1",
        "apiKey": "codebuff-free"
      },
      "models": {
        "deepseek/deepseek-v4-flash": {
          "name": "DeepSeek V4 Flash (Free)",
          "reasoning": true,
          "limit": { "context": 131072, "output": 16384 },
          "pricing": { "input": 0, "output": 0 }
        },
        "deepseek/deepseek-v4-pro": { ... },
        "mimo/mimo-v2.5": { ... },
        "mimo/mimo-v2.5-pro": { ... },
        "moonshotai/kimi-k2.6": { ... },
        "minimax/minimax-m3": { ... }
      }
    }
  }
}
```

Usage:
```bash
opencode run -m codebuff/deepseek/deepseek-v4-flash
```

## Rate Limits

- Free tier: 5 requests/day per model (resets at midnight Pacific)
- Rate limits shown in session creation response:
  ```json
  "rateLimitsByModel": {
    "mimo/mimo-v2.5-pro": {"limit": 5, "period": "pacific_day", "recentCount": 3.5}
  }
  ```
- Reset time: `2026-06-10T07:00:00.000Z` (midnight Pacific = 07:00 UTC)

## Troubleshooting

### "model_locked" error

**Cause**: Trying to create a session for model B while model A's session is still active.
**Fix**: The proxy handles this by doing DELETE before POST, but if the DELETE doesn't propagate fast enough, retry.

### Empty `"content":null` chunks

**Cause**: Previously caused by stripping `reasoning_content` from SSE chunks.
**Fix**: Pipe the SSE stream as-is. OpenCode handles reasoning_content.

### Garbled tool calls (wrong names, broken JSON)

**Cause**: The proxy was reconstructing the request body, dropping `tools`, `tool_choice`, etc.
**Fix**: Forward the original body unchanged, only inject `codebuff_metadata`.

### "no instanceId in" / "no runId in" errors

**Cause**: Codebuff API returned an unexpected response (possibly rate limited or model_locked).
**Fix**: Check proxy logs with `sudo journalctl -u codebuff-proxy.service`.

### Cost > 0

**Cause**: Request went to Codebuff without a valid `freebuff_instance_id`, falling back to paid tier.
**Fix**: Ensure the proxy is running. Check that `codebuff_metadata` is being injected correctly.

## Proxy Logs

```bash
# On VPS
sudo journalctl -u codebuff-proxy.service -f

# Example output:
# [2026-06-10T03:28:36.345Z] POST /v1/chat/completions
#   session 43ea885a-42f9-452f-992a-a74d0c680357 for deepseek/deepseek-v4-flash
#   run 1e4444b8-d5b1-4d20-ad06-f0bde99484c2
#   done
```

## Known Issues

1. **Rate limits**: 5/day for some models. Switch models or wait for reset.
2. **No session caching**: Slightly slower (one extra round trip per request) but avoids stale state bugs.
