# SDK Analysis — @codebuff/sdk

## Package Details

- **Package**: `@codebuff/sdk`
- **Version**: 0.1.172
- **Location**: `/root/.npm/_npx/.../node_modules/@codebuff/sdk`
- **Type**: TypeScript/JavaScript SDK for Codebuff API

## Source Code Analysis

### Provider Options (`getProviderOptions()`)

```typescript
function getProviderOptions() {
  return {
    codebuff: {
      codebuff_metadata: {},  // Empty by default
      provider: {},           // Empty by default
    },
  };
}
```

This generates the `codebuff` key in the request body.

### Request Args (`getArgs()`)

```typescript
function getArgs(options) {
  const { providerOptions, ...rest } = options;
  
  // Spread providerOptions.codebuff into body, filtering out standard keys
  const codebuffOptions = providerOptions?.codebuff || {};
  const filteredOptions = {};
  
  for (const [key, value] of Object.entries(codebuffOptions)) {
    if (!["model", "messages", "stream", "temperature", "max_tokens"].includes(key)) {
      filteredOptions[key] = value;
    }
  }
  
  return {
    ...rest,
    ...filteredOptions,
  };
}
```

This means the final body looks like:
```json
{
  "model": "minimax/minimax-m3",
  "messages": [...],
  "stream": true,
  "codebuff_metadata": {},
  "provider": {}
}
```

### Headers

```typescript
const headers = {
  Authorization: `Bearer ${apiKey}`,
  "user-agent": `ai-sdk/openai-compatible/${VERSION}/codebuff`,
};
```

Key insight: The SDK uses `ai-sdk/openai-compatible` as the User-Agent prefix, NOT `codebuff/0.0.104`.

### URL Construction

```typescript
const url = new URL("/api/v1" + path, "https://www.codebuff.com");
```

Always uses `www.codebuff.com`, not `codebuff.com`.

## API Endpoints in SDK

### Session Management
```typescript
// Create session
POST /api/v1/freebuff/session
Body: { model: string }

// Delete session
DELETE /api/v1/freebuff/session

// Get session status
GET /api/v1/freebuff/session
```

### Agent Runs
```typescript
// Start agent run
POST /api/v1/agent-runs
Body: { action: "START", agentId: string }

// Get agent run status
GET /api/v1/agent-runs/{runId}
```

### Chat Completions
```typescript
// Stream chat completion
POST /api/v1/chat/completions
Body: {
  model: string,
  messages: Array<{ role: string, content: string }>,
  stream: true,
  codebuff_metadata: {
    session_id: string,
    run_id: string
  }
}
```

## Free Mode Flow

1. **Check for existing session**:
   ```typescript
   GET /api/v1/freebuff/session
   ```

2. **Delete existing session if model-bound**:
   ```typescript
   DELETE /api/v1/freebuff/session
   ```

3. **Create new session**:
   ```typescript
   POST /api/v1/freebuff/session
   Body: { model: "minimax/minimax-m3" }
   Response: { id: "session_abc123", status: "WAITING", ... }
   ```

4. **Wait for queue** (polling):
   ```typescript
   GET /api/v1/freebuff/session
   // Check status: "WAITING" → "READY"
   ```

5. **Create agent run**:
   ```typescript
   POST /api/v1/agent-runs
   Body: { action: "START", agentId: "base2-free-minimax-m3" }
   Response: { id: "run_abc123", status: "RUNNING" }
   ```

6. **Stream chat completion**:
   ```typescript
   POST /api/v1/chat/completions
   Body: {
     model: "minimax/minimax-m3",
     messages: [...],
     stream: true,
     codebuff_metadata: {
       session_id: "session_abc123",
       run_id: "run_abc123"
     }
   }
   ```

## Key Findings

1. **`codebuff_metadata` is required** — Without it, the server returns 200 but no content
2. **`action: "START"` is required** — Without it, agent-runs returns 400
3. **`agentId` is required** — Without it, agent-runs returns 400
4. **Sessions are model-bound** — Can't use same session for different models
5. **User-Agent is `ai-sdk/openai-compatible`** — Not `codebuff/0.0.104`
6. **Always uses `www.codebuff.com`** — Not `codebuff.com`

## What the SDK Doesn't Tell Us

The SDK doesn't reveal:
- **TLS fingerprinting** — This is server-side, not in the SDK
- **Rate limits** — Not documented in SDK
- **Queue behavior** — SDK just polls, doesn't explain backoff algorithm
- **Free mode limitations** — Not in SDK code

## Implications for Our Implementation

1. We need to match the SDK's request format exactly
2. We need to include `codebuff_metadata` with valid session_id and run_id
3. We need to use `www.codebuff.com` directly
4. We need to use the correct User-Agent format
5. **Most importantly**: We need to bypass TLS fingerprinting (not in SDK, server-side check)
