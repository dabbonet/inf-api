# Container Setup — Docker Configuration

## Container Details

- **Name**: `dabbo`
- **Image**: `ghcr.io/openclaw/openclaw:2026.6.1`
- **Platform**: linux/arm64 (GCP e2-standard-2)
- **User**: `root` (entrypoint) → `node` (gateway)

## Port Mapping

```
Host 33815 → Container 33815 (OpenClaw gateway)
Host 8323 → Container 8323 (TLS proxy, internal only)
```

## Volume Mounts

```
/home/ubuntu/dabbo-state/.openclaw → /home/node/.openclaw (config, state)
```

## Entrypoint Script

**Host path**: `/tmp/dabbo-entrypoint.sh`
**Container path**: Copied to `/tmp/` at runtime

```bash
#!/bin/bash
set -e

echo "=== Dabbo Entrypoint ==="

# Install Python deps for TLS proxy
echo "Installing tls-client..."
pip3 install --break-system-packages tls-client typing_extensions 2>/dev/null || true

# Start TLS proxy in background
echo "Starting TLS proxy..."
nohup python3 /home/node/.openclaw/extensions/codebuff/proxy.py > /tmp/proxy.log 2>&1 &
PROXY_PID=$!
echo "TLS proxy started (PID: $PROXY_PID)"

# Wait for proxy to be ready
echo "Waiting for proxy..."
for i in $(seq 1 20); do
    if curl -s http://127.0.0.1:8323/health > /dev/null 2>&1; then
        echo "Proxy ready"
        break
    fi
    if [ $i -eq 20 ]; then
        echo "Proxy failed to start, checking logs:"
        cat /tmp/proxy.log
    fi
    sleep 0.5
done

# Start OpenClaw gateway as node user
echo "Starting OpenClaw gateway..."
exec runuser -u node -- node /app/openclaw.mjs gateway --bind custom --port 33815 -- "$@"
```

## Container Creation Command

```bash
docker run -d \
  --name dabbo \
  -p 33815:33815 \
  -v /home/ubuntu/dabbo-state/.openclaw:/home/node/.openclaw \
  --entrypoint bash \
  ghcr.io/openclaw/openclaw:2026.6.1 \
  -c "
    pip3 install --break-system-packages tls-client typing_extensions 2>/dev/null || true
    cat /home/node/.openclaw/extensions/codebuff/proxy.py > /tmp/proxy.py 2>/dev/null || true
    nohup python3 /tmp/proxy.py > /tmp/proxy.log 2>&1 &
    sleep 2
    exec runuser -u node -- node /app/openclaw.mjs gateway --bind custom --port 33815 -- \"\$@\"
  "
```

## Or Using the Entrypoint Script

```bash
# Copy entrypoint to host
cat > /tmp/dabbo-entrypoint.sh << 'EOF'
#!/bin/bash
set -e
echo "=== Dabbo Entrypoint ==="
pip3 install --break-system-packages tls-client typing_extensions 2>/dev/null || true
nohup python3 /home/node/.openclaw/extensions/codebuff/proxy.py > /tmp/proxy.log 2>&1 &
PROXY_PID=$!
echo "TLS proxy started (PID: $PROXY_PID)"
for i in $(seq 1 20); do
    if curl -s http://127.0.0.1:8323/health > /dev/null 2>&1; then
        echo "Proxy ready"
        break
    fi
    sleep 0.5
done
exec runuser -u node -- node /app/openclaw.mjs gateway --bind custom --port 33815 -- "$@"
EOF
chmod +x /tmp/dabbo-entrypoint.sh

# Create container
docker run -d \
  --name dabbo \
  -p 33815:33815 \
  -v /home/ubuntu/dabbo-state/.openclaw:/home/node/.openclaw \
  -v /tmp/dabbo-entrypoint.sh:/tmp/dabbo-entrypoint.sh:ro \
  --entrypoint bash \
  ghcr.io/openclaw/openclaw:2026.6.1 \
  /tmp/dabbo-entrypoint.sh
```

## Installed Tools in Container

```bash
# Networking
apt-get install -y socat tshark tcpdump mitmproxy expect python3-pip

# Python packages
pip3 install --break-system-packages tls-client typing_extensions
```

## Container State

### Files in Container
```
/home/node/.openclaw/
├── openclaw.json              # Main config
├── extensions/
│   ├── commandcode/           # Working plugin (reference)
│   │   ├── index.ts
│   │   ├── openclaw.plugin.json
│   │   └── package.json
│   └── codebuff/              # Codebuff plugin (not loading)
│       ├── index.ts
│       ├── openclaw.plugin.json
│       ├── package.json
│       └── proxy.py           # TLS proxy
├── agents/main/agent/
│   └── auth-profiles.json     # API key auth
└── ...

/root/.config/manicode/
└── freebuff                   # Freebuff binary (129MB)

/root/.bun/bin/
└── bun                        # Bun runtime (v1.3.14)
```

### Running Processes
```
# Main gateway
node /app/openclaw.mjs gateway --bind custom --port 33815

# TLS proxy
python3 /home/node/.openclaw/extensions/codebuff/proxy.py
```

## Troubleshooting

### Proxy Not Starting
```bash
# Check proxy logs
docker exec dabbo cat /tmp/proxy.log

# Check if pip deps installed
docker exec dabbo pip3 list | grep tls

# Start proxy manually
docker exec -u root dabbo nohup python3 /home/node/.openclaw/extensions/codebuff/proxy.py > /tmp/proxy.log 2>&1 &

# Test proxy
curl http://localhost:8323/health
```

### Gateway Not Loading Plugin
```bash
# Check logs for plugin discovery
docker exec dabbo grep -i "codebuff\|discovered\|extension" /tmp/openclaw/openclaw-*.log

# Check plugin files
docker exec dabbo ls -la /home/node/.openclaw/extensions/codebuff/

# Check file ownership
docker exec dabbo stat /home/node/.openclaw/extensions/codebuff/index.ts
```

### Container Won't Start
```bash
# Check container logs
docker logs dabbo

# Check entrypoint
docker exec dabbo cat /tmp/dabbo-entrypoint.sh

# Start interactively
docker run -it --rm \
  -v /home/ubuntu/dabbo-state/.openclaw:/home/node/.openclaw \
  --entrypoint bash \
  ghcr.io/openclaw/openclaw:2026.6.1
```
