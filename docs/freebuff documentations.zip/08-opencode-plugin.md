# OpenCode Plugin & Proxy

## Overview

An OpenCode plugin and proxy server for using Codebuff/Freebuff models in local development. Routes requests through the Python TLS proxy to bypass JA3 fingerprinting.

## Files

### OpenCode Plugin

**Location**: `~/.config/opencode/plugins/codebuff.ts`

```typescript
// OpenCode plugin for Codebuff/Freebuff
// Routes all requests through Python TLS proxy

const PROXY_BASE = "http://localhost:8323/api/v1";

export default {
  name: "codebuff",
  providers: [
    {
      id: "codebuff",
      name: "Codebuff Free",
      getModels() {
        return [
          { id: "minimax/minimax-m3", name: "Minimax M3" },
          { id: "mimo/mimo-v2.5-pro", name: "Mimo V2.5 Pro" },
          { id: "mimo/mimo-v2.5", name: "Mimo V2.5" },
          { id: "deepseek/deepseek-v4-pro", name: "Deepseek V4 Pro" },
          { id: "deepseek/deepseek-v4-flash", name: "Deepseek V4 Flash" },
          { id: "moonshotai/kimi-k2.6", name: "Kimi K2.6" },
        ];
      },
      async doStream({ prompt, model, system }) {
        // Step 1: Create session
        const sessionRes = await fetch(`${PROXY_BASE}/freebuff/session`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${API_KEY}` },
        });
        
        const createRes = await fetch(`${PROXY_BASE}/freebuff/session`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ model }),
        });
        const session = await createRes.json();

        // Step 2: Create agent run
        const agentId = getAgentId(model);
        const runRes = await fetch(`${PROXY_BASE}/agent-runs`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ action: "START", agentId }),
        });
        const run = await runRes.json();

        // Step 3: Stream chat completion
        const messages = [];
        if (system) messages.push({ role: "system", content: system });
        messages.push({ role: "user", content: prompt });

        const res = await fetch(`${PROXY_BASE}/chat/completions`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model,
            stream: true,
            messages,
            codebuff_metadata: {
              session_id: session.id,
              run_id: run.id,
            },
          }),
        });

        // Parse SSE stream
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6).trim();
            if (data === "[DONE]") return;

            try {
              const chunk = JSON.parse(data);
              const delta = chunk.choices?.[0]?.delta;
              if (delta?.reasoning_content) {
                yield { type: "reasoning", text: delta.reasoning_content };
              }
              if (delta?.content) {
                yield { type: "text", text: delta.content };
              }
            } catch {}
          }
        }
      },
    },
  ],
};

function getAgentId(model: string): string {
  const map: Record<string, string> = {
    "minimax/minimax-m3": "base2-free-minimax-m3",
    "mimo/mimo-v2.5-pro": "base2-free-mimo-pro",
    "mimo/mimo-v2.5": "base2-free-mimo",
    "deepseek/deepseek-v4-pro": "base2-free-deepseek-pro",
    "deepseek/deepseek-v4-flash": "base2-free-deepseek-flash",
    "moonshotai/kimi-k2.6": "base2-free-kimi",
  };
  return map[model] || "base2-free-minimax-m3";
}
```

### OpenCode Proxy Server

**Location**: `~/.config/opencode/codebuff-proxy/server.js`

A standalone Node.js proxy that:
1. Receives requests from OpenCode
2. Forwards to Python TLS proxy (port 8323)
3. Returns response to OpenCode

```javascript
import http from "node:http";

const PROXY_HOST = "127.0.0.1";
const PROXY_PORT = 8322;
const TLS_PROXY = "http://127.0.0.1:8323";

const server = http.createServer(async (req, res) => {
  try {
    // Forward to TLS proxy
    const proxyRes = await fetch(`${TLS_PROXY}${req.url}`, {
      method: req.method,
      headers: req.headers,
      body: ["POST", "PUT", "PATCH"].includes(req.method)
        ? await collectBody(req)
        : undefined,
    });

    // Forward response
    res.writeHead(proxyRes.status, Object.fromEntries(proxyRes.headers));
    const body = await proxyRes.arrayBuffer();
    res.end(Buffer.from(body));
  } catch (err) {
    console.error("Proxy error:", err);
    res.writeHead(502);
    res.end("Bad Gateway");
  }
});

server.listen(PROXY_PORT, PROXY_HOST, () => {
  console.log(`OpenCode proxy listening on http://${PROXY_HOST}:${PROXY_PORT}`);
});

async function collectBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}
```

## Setup

### 1. Start Python TLS Proxy

```bash
# In container
python3 /home/node/.openclaw/extensions/codebuff/proxy.py &
```

### 2. Start OpenCode Proxy

```bash
# Locally
node ~/.config/opencode/codebuff-proxy/server.js &
```

### 3. Configure OpenCode

In `~/.config/opencode/opencode.json`:
```json
{
  "providers": {
    "codebuff": {
      "apiKey": "cb-pat-ff60c395ec09d3fcb405a84b667254552594f134517e4ce4fe923c3fbd58e206"
    }
  }
}
```

## Usage

```bash
# Use in OpenCode
opencode --model codebuff/minimax/minimax-m3

# Or set as default in config
```

## Rate Limits

- Free mode: Limited requests (resets at midnight Pacific)
- `recentCount`: ~4.3/5 when last checked
- Reset time: `2026-06-10T07:00:00.000Z`

## Known Issues

1. **Proxy must be running** — Both Python TLS proxy and Node.js proxy must be started
2. **Fresh container** — Need to `pip3 install tls-client` on fresh containers
3. **Session cleanup** — Old sessions must be deleted before creating new ones for different models
