# Failed Approaches — DO NOT REPEAT

This document lists every approach that was tried and failed. **Do not attempt any of these again** — they are all dead ends.

## Category 1: Header Spoofing

### ❌ Spoofing User-Agent to "codebuff/1.x"
**What was tried**: Set `User-Agent: codebuff/0.0.104` in HTTP requests
**Result**: 403 `free_mode_cli_required`
**Why it fails**: Server checks TLS fingerprint, not HTTP User-Agent header

### ❌ Spoofing Content-Type
**What was tried**: Various Content-Type values
**Result**: Already correct as `application/json`, doesn't affect TLS check

### ❌ Adding custom headers
**What was tried**: X-Codebuff-Version, X-Codebuff-CLI, various custom headers
**Result**: 403 `free_mode_cli_required` — headers don't affect TLS check

### ❌ Spoofing Origin/Referer
**What was tried**: Various Origin and Referer values
**Result**: Already correct as `https://www.codebuff.com`

## Category 2: Body Format Manipulation

### ❌ Adding codebuff_metadata without valid run_id
**What was tried**: Send `codebuff_metadata` with fake session_id/run_id
**Result**: 403 `free_mode_cli_required`

### ❌ Removing codebuff_metadata
**What was tried**: Send chat completions without `codebuff_metadata`
**Result**: 200 OK but no actual response content (just headers)

### ❌ Changing model IDs
**What was tried**: Use `codebuff-mini`, `deepseek-v3`, etc.
**Result**: 400 `Invalid model` — only specific free models work

### ❌ Using paid model IDs
**What was tried**: Use `anthropic/claude-3.5-sonnet`, etc.
**Result**: 400 or 403 — paid models require subscription

### ❌ Changing agentId format
**What was tried**: Various agentId formats
**Result**: 400 — must use exact agentId like `base2-free-minimax-m3`

## Category 3: Session/Auth Manipulation

### ❌ Creating sessions without DELETE first
**What was tried**: POST session without DELETE
**Result**: 400 if existing session for different model exists

### ❌ Using cookies for auth
**What was tried**: Extract and use session cookies
**Result**: Server uses Bearer token auth, not cookies

### ❌ Using web app API keys
**What was tried**: Use API keys from web dashboard
**Result**: Different auth mechanism, doesn't work for CLI API

### ❌ Creating multiple sessions
**What was tried**: Create sessions for multiple models simultaneously
**Result**: Only one active session per user

## Category 4: TLS/Network Workarounds

### ❌ Using curl with --insecure
**What was tried**: `curl -k` to skip cert verification
**Result**: Still gets 403 — cert verification is not the issue

### ❌ Using different User-Agent with curl
**What was tried**: `curl -A "Mozilla/5.0 ..."`
**Result**: Still gets 403 — JA3 fingerprint is the issue, not HTTP headers

### ❌ Using Bun.run
**What was tried**: Bun's built-in fetch
**Result**: 403 — Bun uses BoringSSL which has detectable JA3

### ❌ Using Node.js fetch
**What was tried**: Node.js built-in fetch
**Result**: 403 — Node.js uses OpenSSL which has detectable JA3

### ❌ Using Python requests
**What was tried**: `requests.get/post`
**Result**: 403 — Python requests uses system OpenSSL

### ❌ Using httpx
**What was tried**: `httpx.get/post`
**Result**: 403 — httpx uses system OpenSSL

### ❌ Using aiohttp
**What was tried**: `aiohttp.ClientSession`
**Result**: 403 — aiohttp uses system OpenSSL

### ❌ Using Go net/http
**What was tried**: Go's standard HTTP client
**Result**: 403 — Go's crypto/tls has detectable JA3

## Category 5: Binary Analysis Dead Ends

### ❌ Decompiling the freebuff binary
**What was tried**: Attempted to decompile the 129MB Bun-compiled binary
**Result**: Too large, no useful decompilation tools available

### ❌ Extracting API keys from binary
**What was tried**: `strings` on binary, searching for key patterns
**Result**: No embedded API keys found

### ❌ Analyzing /proc/PID/maps
**What was tried**: Check memory mappings for secrets
**Result**: Bun's lazy loading means secrets aren't in memory yet

### ❌ Using strace to capture secrets
**What was tried**: `strace -e trace=read,write` on the binary
**Result**: Bun uses epoll, not standard read/write for network I/O

### ❌ Using mitmproxy
**What was tried**: Intercept TLS traffic with mitmproxy
**Result**: Binary uses certificate pinning, can't intercept

## Category 6: Plugin System

### ❌ Adding to plugins.allow
**What was tried**: Set `plugins.allow: ["codebuff"]`
**Result**: Gateway logs "plugins.allow is empty" — config not being read for allow list

### ❌ Removing plugins.allow
**What was tried**: Remove `plugins.allow` entirely
**Result**: 13 plugins load, but codebuff still not among them

### ❌ Copying commandcode structure
**What was tried**: Copy exact file structure from working commandcode plugin
**Result**: Still not discovered

### ❌ Removing Node.js builtin imports
**What was tried**: Remove `fs` and `path` imports from index.ts
**Result**: Still not discovered

### ❌ Installing via npm
**What was tried**: `npm install` in the plugin directory
**Result**: Still not discovered

### ❌ Adding node_modules directory
**What was tried**: Create empty node_modules
**Result**: Still not discovered

## Category 7: Freebuff.com Dead Ends

### ❌ Calling freebuff.com API
**What was tried**: All paths on freebuff.com
**Result**: 404 HTML — freebuff.com has NO API endpoints

### ❌ Using freebuff.com for auth
**What was tried**: Login flow on freebuff.com
**Result**: Uses different auth mechanism, not compatible with CLI API

## Summary: What Actually Works

The ONLY thing that works is:
1. **Python `tls_client` with Chrome 124 profile** — produces browser-like JA3 fingerprint
2. **3-step flow**: DELETE session → POST session → POST agent-runs → POST chat/completions
3. **Proxy approach**: Python proxy on localhost:8323 forwards requests with correct TLS fingerprint

Everything else is a dead end. Do not waste time on header spoofing, body manipulation, or TLS workarounds other than `tls_client`.
