# Codebuff/Freebuff Free Mode — Complete Documentation

## Current Architecture (NL IP Proxy)

```
┌──────────┐     ┌──────────────────────────┐     ┌─────────────────────┐
│ OpenCode │────▶│  Node.js Proxy (:3456)  │────▶│  codebuff.com API   │
│ (local)  │     │  (GCP VPS, Netherlands) │     │  (free tier)        │
└──────────┘     └──────────────────────────┘     └─────────────────────┘
                                            │
                                    Netherlands IP
                                    (bypasses all TLS checks)
```

**Key insight**: Codebuff's free tier is region-locked, not TLS-fingerprinted. Requests from a Netherlands (NL) IP address get full free tier access without any JA3 fingerprint checks.

## Setup

### 1. VPS (GCP, Netherlands region)

Create a GCP VM in `europe-west4` (Netherlands), install Node.js, run the proxy:

```bash
# On the VPS
node /tmp/codebuff-proxy.js
```

Or use systemd for auto-start (see `11-nl-ip-proxy.md`).

### 2. OpenCode Config

In `~/.config/opencode/opencode.json`:

```json
{
  "model": "opencode/mimo-v2.5-free",
  "provider": {
    "codebuff": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Codebuff (Free via NL)",
      "options": {
        "baseURL": "http://34.6.156.250:3456/v1",
        "apiKey": "codebuff-free"
      },
      "models": {
        "deepseek/deepseek-v4-flash": { ... },
        "deepseek/deepseek-v4-pro": { ... },
        "mimo/mimo-v2.5": { ... },
        "mimo/mimo-v2.5-pro": { ... },
        "moonshotai/kimi-k2.6": { ... },
        "minimax/minimax-m3": { ... }
      }
    }
  }
}
```

## Files

| File | Description |
|------|-------------|
| `01-api-endpoints.md` | All API endpoints, request/response formats, 3-step flow |
| `02-tls-fingerprinting.md` | JA3 fingerprinting discovery (historical — no longer needed) |
| `03-proxy-server.md` | Python TLS proxy (historical — no longer needed) |
| `04-openclaw-plugin.md` | OpenClaw TypeScript plugin (historical — no longer needed) |
| `05-failed-approaches.md` | Every approach that didn't work (DO NOT repeat these) |
| `06-binary-analysis.md` | Findings from the freebuff CLI binary |
| `07-sdk-analysis.md` | Findings from the @codebuff/sdk npm package |
| `08-opencode-plugin.md` | OpenCode plugin for local development (historical) |
| `09-credentials.md` | API keys, model IDs, agent IDs, rate limits |
| `10-container-setup.md` | Docker container configuration (historical) |
| `11-nl-ip-proxy.md` | **Current**: NL IP proxy setup, deployment, and operation |

## Quick Start (Current)

1. Ensure the VPS proxy is running: `curl -s http://34.6.156.250:3456/v1/models`
2. Use OpenCode with `codebuff/` models: `opencode run -m codebuff/deepseek/deepseek-v4-flash`

## Current Status

- ✅ NL IP proxy — works, cost: 0, all models available
- ✅ Tool calling — works, original request body forwarded as-is
- ✅ Model switching — works, DELETE + POST sequential
- ✅ SSE streaming — raw pipe, no filtering, reasoning_content preserved
- ✅ Non-streaming fallback — collects SSE and reconstructs JSON
- ✅ OpenAI-compatible — `/v1/models`, `/v1/chat/completions`
- ❌ Rate limits — 5/day for some models (resets at midnight Pacific)
- ❌ No session caching — fresh session per request (simplicity over perf)

## Historical Notes

The original approach used JA3 TLS fingerprinting bypass via Python's `tls_client` library (Chrome 124 profile). This was necessary because Codebuff checked TLS fingerprints against the official CLI binary. The NL IP approach made this obsolete — Codebuff's free tier is gated by IP geolocation, not TLS fingerprint.

See `05-failed-approaches.md` for approaches that didn't work (DO NOT repeat them).
