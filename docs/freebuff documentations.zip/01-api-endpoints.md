# API Endpoints — Complete Reference

## Base URLs

- **Production (web app)**: `https://codebuff.com` → redirects to `https://www.codebuff.com`
- **API (use this)**: `https://www.codebuff.com/api/v1`
- **Freebuff (NO API endpoints)**: `https://freebuff.com` — all paths return 404 HTML

**IMPORTANT**: Always use `www.codebuff.com` directly. Using `codebuff.com` causes a 307 redirect to `www.codebuff.com` which **strips Authorization headers**.

## Authentication

All API calls require:
```
Authorization: Bearer cb-pat-ff60c395ec09d3fcb405a84b667254552594f134517e4ce4fe923c3fbd58e206
```

## Free Mode 3-Step Flow

### Step 1: Create Session (or Reset Existing)

**DELETE** existing session if model-bound session exists:
```
DELETE https://www.codebuff.com/api/v1/freebuff/session
Authorization: Bearer <API_KEY>
```
Response: `204 No Content`

**POST** to create new session:
```
POST https://www.codebuff.com/api/v1/freebuff/session
Authorization: Bearer <API_KEY>
Content-Type: application/json

{
  "model": "minimax/minimax-m3"
}
```
Response:
```json
{
  "id": "session_abc123",
  "createdAt": "2026-06-09T18:16:09.350Z",
  "totalTokens": 0,
  "status": "WAITING",
  "statusMessage": "You are 3 out of 3 in the waiting room.",
  "model": "minimax/minimax-m3",
  "currentAgentRunId": null
}
```

**Models available for free mode**:
- `minimax/minimax-m3`
- `mimo/mimo-v2.5-pro`
- `mimo/mimo-v2.5`
- `deepseek/deepseek-v4-pro`
- `deepseek/deepseek-v4-flash`
- `moonshotai/kimi-k2.6`

**IMPORTANT**: Sessions are MODEL-BOUND. If you create a session for `minimax-m3` and then try to use `mimo-v2.5-pro`, you'll get a 400 error. You MUST DELETE the existing session first, then create a new one for the desired model.

### Step 2: Create Agent Run

```
POST https://www.codebuff.com/api/v1/agent-runs
Authorization: Bearer <API_KEY>
Content-Type: application/json

{
  "action": "START",
  "agentId": "base2-free-minimax-m3"
}
```

**Required fields**:
- `action`: Must be `"START"` (without this, 400 error)
- `agentId`: Must match the model (without this, 400 error)

**Agent IDs** (must match model):
| Model | Agent ID |
|-------|----------|
| `minimax/minimax-m3` | `base2-free-minimax-m3` |
| `mimo/mimo-v2.5-pro` | `base2-free-mimo-pro` |
| `mimo/mimo-v2.5` | `base2-free-mimo` |
| `deepseek/deepseek-v4-pro` | `base2-free-deepseek-pro` |
| `deepseek/deepseek-v4-flash` | `base2-free-deepseek-flash` |
| `moonshotai/kimi-k2.6` | `base2-free-kimi` |

Response:
```json
{
  "id": "run_abc123",
  "status": "RUNNING",
  "agentId": "base2-free-minimax-m3"
}
```

### Step 3: Chat Completions

```
POST https://www.codebuff.com/api/v1/chat/completions
Authorization: Bearer <API_KEY>
Content-Type: application/json

{
  "model": "minimax/minimax-m3",
  "stream": true,
  "messages": [
    {"role": "user", "content": "Hello, how are you?"}
  ],
  "codebuff_metadata": {
    "session_id": "session_abc123",
    "run_id": "run_abc123"
  }
}
```

**CRITICAL**: The `codebuff_metadata` field is what triggers the TLS fingerprint check. Without it, you get 200 but no actual response. With it AND wrong TLS fingerprint, you get 403 `free_mode_cli_required`.

**Response** (streaming SSE):
```
HTTP/1.1 200 OK
content-type: text/event-stream; charset=utf-8
x-freebuff-finish-reason: stop
x-freebuff-model: Minimax-M3.5
x-freebuff-app-title: FreeMinimax3.5

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1749502569,"model":"minimax/minimax-m3","choices":[{"index":0,"delta":{"role":"assistant","content":""},"finish_reason":null,"content_filter_results":{}}],"usage":{"prompt_tokens":1651,"total_tokens":1651,"completion_tokens":0,"prompt_tokens_details":{"cached_tokens":1441}}}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1749502569,"model":"minimax/minimax-m3","choices":[{"index":0,"delta":{"reasoning_content":"Let me consider"},"finish_reason":null,"content_filter_results":{}}],"usage":{"prompt_tokens":1651,"total_tokens":1651,"completion_tokens":0}}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1749502569,"model":"minimax/minimax-m3","choices":[{"index":0,"delta":{"content":"I'm doing well!"},"finish_reason":null,"content_filter_results":{}}],"usage":{"prompt_tokens":1651,"total_tokens":1651,"completion_tokens":0}}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1749502569,"model":"minimax/minimax-m3","choices":[{"index":0,"delta":{},"finish_reason":"stop","content_filter_results":{}}],"usage":{"prompt_tokens":1651,"total_tokens":1686,"completion_tokens":35}}

data: [DONE]
```

**Key response fields**:
- `delta.reasoning_content`: Thinking/reasoning tokens (shown as `> ` prefixed lines in CLI)
- `delta.content`: Actual response content
- `usage.prompt_tokens`: Input tokens
- `usage.completion_tokens`: Output tokens
- `finish_reason: "stop"`: Normal completion

**Other headers**:
- `x-freebuff-finish-reason`: `stop`, `length`, `content_filter`, or `max_tokens`
- `x-freebuff-model`: Display name of the model
- `x-freebuff-app-title`: App title (e.g., `FreeMinimax3.5`)

## Other API Endpoints Discovered

### Health Check
```
GET https://www.codebuff.com/health
```
Response: `OK`

### Get User Info
```
GET https://www.codebuff.com/api/v1/me
Authorization: Bearer <API_KEY>
```
Response: User info with `hasCodebuffPro: true/false`

### Get Free Models
```
GET https://www.codebuff.com/api/v1/free-models
Authorization: Bearer <API_KEY>
```
Response: List of available free models

### CLI Config
```
GET https://www.codebuff.com/api/v1/cli-config
Authorization: Bearer <API_KEY>
```
Response: CLI configuration (check interval, etc.)

## Rate Limits

- Free mode: Limited requests (exact limit unknown, resets at midnight Pacific)
- `recentCount`: ~4.3/5 when we last checked
- Reset time: `2026-06-10T07:00:00.000Z` (midnight Pacific)

## Headers Required

```
Authorization: Bearer <API_KEY>
Content-Type: application/json
Origin: https://www.codebuff.com
Referer: https://www.codebuff.com/
```

**NEVER forward** these headers upstream (they cause Cloudflare 400):
- `User-Agent` (any non-browser UA)
- `Accept` (if it's curl/Node.js default)

## Freebuff vs Codebuff

- **codebuff.com**: Paid product, has API endpoints
- **freebuff.com**: Free tier frontend only, NO API endpoints (all paths return 404 HTML)
- The freebuff CLI binary uses codebuff.com API for ALL operations (free and paid mode)
