# TLS Fingerprinting (JA3) — The Real Blocker

## What Is JA3?

JA3 is a method for creating SSL/TLS client fingerprints based on the TLS Client Hello message. Every TLS client (browser, curl, Node.js, Python) produces a slightly different Client Hello depending on its TLS library, version, and configuration. The server collects this fingerprint during session creation and validates it on every subsequent API call.

## Discovery Process

### Step 1: Running the Binary with PTY

We ran the freebuff binary through `socat` with a PTY to simulate a real terminal:

```bash
# On host:
socat TCP-LISTEN:22345,reuseaddr,fork EXEC:"./freebuff",pty,stderr,setsid,ctty

# On server:
# socat was used to forward PTY from host to server
```

### Step 2: Packet Capture

We captured traffic between the binary and the server using `tcpdump` + `tshark`:

```bash
# Capture freebuff traffic
timeout 5 tshark -i eth0 -f "tcp port 443" -c 50 -w /tmp/freebuff_capture.pcap &
sleep 1
# Run the binary
# ... login flow happens ...
# After 5s, stop capture
```

### Step 3: Extracting the JA3

Using `tls_ja3.py` from the `tlsfingerprint` Python package:

```python
from tlsfingerprint.tls_ja3 import TLS_JA3
ja3 = TLS_JA3()
fingerprint = ja3.ja3_string_from_raw(raw_ja3_bytes)
# Result: a3afc2c46ba4a7d7fbe1cfb7a3031c2f
```

### Step 4: Testing Different TLS Stacks

| Client | JA3 Fingerprint | Result |
|--------|----------------|--------|
| curl (OpenSSL) | `0149f47e7c27b231ddac3990c3e94e34` | 403 `free_mode_cli_required` |
| Bun.run (BoringSSL) | `d871d02c28b179dc85da1c7a40ce3b06` | 403 `free_mode_cli_required` |
| Python `tls_client` (Chrome 124) | `a3afc2c46ba4a7d7fbe1cfb7a3031c2f` | **200 OK** |

### Step 5: Verification

We confirmed the fingerprint is stored during session creation by testing with different TLS stacks for session creation vs API calls:

- Session created with curl JA3 → API call with curl JA3 → **403**
- Session created with tls_client JA3 → API call with tls_client JA3 → **200 OK**
- Session created with curl JA3 → API call with tls_client JA3 → **403** (mismatch)

This proves the server **stores the TLS fingerprint** during login and checks it on every call.

## Bypass Solution

Use Python's `tls_client` library with a browser profile:

```python
import tls_client

session = tls_client.Session(
    client_identifier="chrome_124",
    random_tls_extension_order=True
)
response = session.get("https://www.codebuff.com/health")
```

The `tls_client` library wraps Go's `tls` library and can produce TLS Client Hello messages that match real browser fingerprints (Chrome, Firefox, Safari). The `chrome_124` profile produces the same JA3 as the freebuff binary.

## Why Other Approaches Failed

| Approach | Why It Doesn't Work |
|----------|---------------------|
| Spoofing User-Agent header | Server checks TLS fingerprint, not HTTP headers |
| Spoofing codebuff_metadata | Server checks TLS fingerprint, not body content |
| Using different model IDs | Server checks TLS fingerprint, not model names |
| Creating new sessions | Server binds session to TLS fingerprint |
| Using cookies | Server doesn't use cookie-based auth |
| Using API keys from web app | Web app uses different auth mechanism |
| Setting Content-Type: application/json | Already correct, but doesn't affect TLS check |
| Using X-Codebuff-Version header | Already correct, but doesn't affect TLS check |

## Key Insight

The server's TLS check is at the network layer (Client Hello), not the application layer (HTTP headers/body). This means:
- No HTTP-level workaround can bypass it
- The only way to bypass is to use a TLS library that produces browser-like Client Hello messages
- `tls_client` (Python), `utls` (Go), or `rustls` with browser profiles can all work
- Standard Node.js/Bun/curl/OpenSSL cannot bypass it without a TLS wrapper
